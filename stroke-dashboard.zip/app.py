import streamlit as st

st.set_page_config(page_title="Stroke Prediction Dashboard", layout="wide")

st.title("Stroke Prediction Dashboard")
st.write("Gunakan sidebar untuk navigasi halaman:")
